﻿Public Class Sucursales
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Opciones.Show()
        If CheckBox1.Checked = True Then
            Opciones.ListBox1.Items.Add(
"Sucursal Cumbres - Monterrey, NL
📍 Av. Paseo de los Leones #4523, Col. Cumbres Elite, Monterrey, NL")
        End If
        If CheckBox2.Checked = True Then
            Opciones.ListBox1.Items.Add(
"Sucursal Centro - Oaxaca, OAX
📍 Calle de los Libres #108, Col. Centro, Oaxaca de Juárez, OAX")
        End If
        If CheckBox3.Checked = True Then
            Opciones.ListBox1.Items.Add(
"Sucursal Playa - Cancún, QROO
📍 Av. Kabah #236, SM 57, Cancún, Quintana Roo")
        End If
        If CheckBox4.Checked = True Then
            Opciones.ListBox1.Items.Add(
"Sucursal Norte - Hermosillo, SON
📍 Blvd. Solidaridad #880, Col. San Benito, Hermosillo, Sonora")
        End If
        If CheckBox5.Checked = True Then
            Opciones.ListBox1.Items.Add(
"Sucursal Sur - Tlalpan, CDMX
📍 Calzada de Tlalpan #3540, Col. Villa Coapa, CDMX")
        End If
        If CheckBox6.Checked = True Then
            Opciones.ListBox1.Items.Add(
"Sucursal Chapultepec - Guadalajara, JAL
📍 Av. Chapultepec Sur #121, Col. Americana, Guadalajara, Jalisco")
        End If
        If CheckBox7.Checked = True Then
            Opciones.ListBox1.Items.Add(
"Sucursal Frontera - Tijuana, BC
📍 Blvd. Insurgentes #9900, Col. El Lago, Tijuana, Baja California")
        End If
        If CheckBox8.Checked = True Then
            Opciones.ListBox1.Items.Add(
"Sucursal Cuautitlán - Estado de México
📍 Av. 16 de Septiembre #78, Cuautitlán Izcalli, Edo. de México")
        End If
        If CheckBox9.Checked = True Then
            Opciones.ListBox1.Items.Add(
"Sucursal Internacional - San Diego, CA (EE.UU.)
📍 1234 Border View Dr., Chula Vista, CA, USA")
        End If
        If CheckBox10.Checked = True Then
            Opciones.ListBox1.Items.Add(
"Sucursal Andina - Medellín, Colombia
📍 Calle 10A #34-45, El Poblado, Medellín, Colombia")
        End If
    End Sub

    Private Sub Sucursales_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class