﻿Public Class BajaRotacionForm
    Inherits Form
    Private Sub BajaRotacionForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dgvBajaRotacion.Columns.Add("codigo", "Código")
        dgvBajaRotacion.Columns.Add("producto", "Producto")
        dgvBajaRotacion.Columns.Add("cantidad", "Cantidad")
        dgvBajaRotacion.Columns.Add("ubicacion", "Ubicación")

        ' Simulamos datos de baja rotación (poca existencia)
        dgvBajaRotacion.Rows.Add("LL004", "Llantas 13'' Hankook", 3, "Estante C1")
        dgvBajaRotacion.Rows.Add("LL005", "Llantas 18'' Firestone", 2, "Estante C2")
        dgvBajaRotacion.Rows.Add("LL013", "Llantas 17'' Kumho", 1, "Estante B3")
        dgvBajaRotacion.Rows.Add("LL015", "Llantas 14'' Giti", 2, "Estante A4")
        dgvBajaRotacion.Rows.Add("LL016", "Llantas 12'' Maxxis", 3, "Estante D3")
    End Sub

    Private Sub lblTitulo_Click(sender As Object, e As EventArgs) Handles lblTitulo.Click

    End Sub

    Private Sub dgvBajaRotacion_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvBajaRotacion.CellContentClick

    End Sub

    Private Sub btnVolver_Click(sender As Object, e As EventArgs) Handles btnVolver.Click
        Me.Close()
    End Sub
End Class