﻿Imports System.IO

Public Class Llantas1
    ' Listas temporales para guardar selección
    Public Shared ListaNombres As New List(Of String)
    Public Shared ListaDescripciones As New List(Of String)
    Public Shared ListaCantidades As New List(Of Integer)

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If TextBox1.Text = "" Then
            MsgBox("Ingrese la cantidad")
            Exit Sub
        End If

        Dim cantidadCompra As Integer = Integer.Parse(TextBox1.Text)

        ' Guardar selección en listas temporales según CheckBox marcado
        If CheckBox1.Checked Then
            ListaNombres.Add("Bridgestone Turanza T005")
            ListaDescripciones.Add("205/55 R16")
            ListaCantidades.Add(cantidadCompra)
        End If
        If CheckBox2.Checked Then
            ListaNombres.Add("BFGoodrich All-Terrain T/A KO2")
            ListaDescripciones.Add("265/70 R17")
            ListaCantidades.Add(cantidadCompra)
        End If
        If CheckBox3.Checked Then
            ListaNombres.Add("Michelin Pilot Sport 4")
            ListaDescripciones.Add("225/45 ZR18")
            ListaCantidades.Add(cantidadCompra)
        End If
        If CheckBox4.Checked Then
            ListaNombres.Add("Pirelli Winter Sottozero 3")
            ListaDescripciones.Add("195/65 R15")
            ListaCantidades.Add(cantidadCompra)
        End If
        If CheckBox5.Checked Then
            ListaNombres.Add("Continental ContiSportContact SSR")
            ListaDescripciones.Add("245/40 R19")
            ListaCantidades.Add(cantidadCompra)
        End If
        If CheckBox6.Checked Then
            ListaNombres.Add("Goodyear Assurance Fuel Max")
            ListaDescripciones.Add("185/65 R14")
            ListaCantidades.Add(cantidadCompra)
        End If

        ' Abrir la forma de pago
        CompraLlantas.Show()
    End Sub

    ' Función para actualizar stock y guardar la compra
    Public Shared Sub ActualizarStockYGuardar(nombre As String, descripcion As String, cantidadCompra As Integer)

        Dim rutaDatos As String = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "DatosSeparados.txt")

        ' Guardar en AlmacenVB.txt
        Dim contenidoAlmacen As String = "Nombre: " & nombre & Environment.NewLine &
                                         "Descripcion: " & descripcion & Environment.NewLine &
                                         "Cantidad: " & cantidadCompra & Environment.NewLine &
                                         "-----------------------------" & Environment.NewLine


        ' Actualizar stock en DatosSeparados.txt
        Dim lineas As List(Of String) = File.ReadAllLines(rutaDatos).ToList()

        For i As Integer = 0 To lineas.Count - 1
            If lineas(i).Contains("Nombre:" & nombre) AndAlso lineas(i).Contains("Descripcion:" & descripcion) Then
                Dim partes() As String = lineas(i).Split(","c)
                For j As Integer = 0 To partes.Length - 1
                    If partes(j).Trim().StartsWith("Cantidad:") Then
                        Dim cantidadActual As Integer = Integer.Parse(partes(j).Split(":"c)(1).Trim())
                        Dim nuevaCantidad As Integer = cantidadActual - cantidadCompra
                        If nuevaCantidad < 0 Then nuevaCantidad = 0
                        partes(j) = "Cantidad:" & nuevaCantidad
                        Exit For
                    End If
                Next
                lineas(i) = String.Join(", ", partes) & ","
                Exit For
            End If
        Next

        File.WriteAllLines(rutaDatos, lineas)
    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub PictureBox1_Click_1(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs)

    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click

    End Sub


    Private Sub CheckBox7_CheckedChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Llantas2.Show()
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub CheckBox5_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox5.CheckedChanged

    End Sub

    Private Sub CheckBox2_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox2.CheckedChanged

    End Sub
End Class