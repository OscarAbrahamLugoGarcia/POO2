﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class CapturaAl
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(CapturaAl))
        Id = New ComboBox()
        Nombre = New ComboBox()
        Fecha = New TextBox()
        mostraringresaid = New Label()
        mostrarnombre = New Label()
        mostrardescripcion = New Label()
        mostrarfecha = New Label()
        mostrarcantida = New Label()
        Cantidad = New TextBox()
        Button1 = New Button()
        btnatras = New Button()
        DataGridView1 = New DataGridView()
        Label1 = New Label()
        descripcion = New ComboBox()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Id
        ' 
        Id.FormattingEnabled = True
        Id.Items.AddRange(New Object() {"MIC1001", "", "MIC1002", "", "BRI2001", "", "BRI2002", "", "GOO3001", "", "GOO3002", "", "CON4001", "", "CON4002"})
        Id.Location = New Point(12, 30)
        Id.Name = "Id"
        Id.Size = New Size(178, 23)
        Id.TabIndex = 0
        ' 
        ' Nombre
        ' 
        Nombre.FormattingEnabled = True
        Nombre.Items.AddRange(New Object() {"Bridgestone Turanza T005", "BFGoodrich All-Terrain T/A KO2", "Michelin Pilot Sport 4", "Pirelli Winter Sottozero 3", "Continental ContiSportContact SSR", "Goodyear Assurance Fuel Max"})
        Nombre.Location = New Point(12, 86)
        Nombre.Name = "Nombre"
        Nombre.Size = New Size(178, 23)
        Nombre.TabIndex = 1
        ' 
        ' Fecha
        ' 
        Fecha.Location = New Point(12, 192)
        Fecha.Name = "Fecha"
        Fecha.Size = New Size(178, 23)
        Fecha.TabIndex = 5
        ' 
        ' mostraringresaid
        ' 
        mostraringresaid.AutoSize = True
        mostraringresaid.Location = New Point(22, 12)
        mostraringresaid.Name = "mostraringresaid"
        mostraringresaid.Size = New Size(59, 15)
        mostraringresaid.TabIndex = 6
        mostraringresaid.Text = "Ingresa ID"
        ' 
        ' mostrarnombre
        ' 
        mostrarnombre.AutoSize = True
        mostrarnombre.Location = New Point(14, 68)
        mostrarnombre.Name = "mostrarnombre"
        mostrarnombre.Size = New Size(51, 15)
        mostrarnombre.TabIndex = 7
        mostrarnombre.Text = "Nombre"
        ' 
        ' mostrardescripcion
        ' 
        mostrardescripcion.AutoSize = True
        mostrardescripcion.Location = New Point(12, 121)
        mostrardescripcion.Name = "mostrardescripcion"
        mostrardescripcion.Size = New Size(69, 15)
        mostrardescripcion.TabIndex = 8
        mostrardescripcion.Text = "Descripcion"
        ' 
        ' mostrarfecha
        ' 
        mostrarfecha.AutoSize = True
        mostrarfecha.Location = New Point(14, 174)
        mostrarfecha.Name = "mostrarfecha"
        mostrarfecha.Size = New Size(38, 15)
        mostrarfecha.TabIndex = 9
        mostrarfecha.Text = "Fecha"
        ' 
        ' mostrarcantida
        ' 
        mostrarcantida.AutoSize = True
        mostrarcantida.Location = New Point(12, 228)
        mostrarcantida.Name = "mostrarcantida"
        mostrarcantida.Size = New Size(55, 15)
        mostrarcantida.TabIndex = 10
        mostrarcantida.Text = "Cantidad"
        ' 
        ' Cantidad
        ' 
        Cantidad.Location = New Point(12, 246)
        Cantidad.Name = "Cantidad"
        Cantidad.Size = New Size(178, 23)
        Cantidad.TabIndex = 11
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(636, 360)
        Button1.Name = "Button1"
        Button1.Size = New Size(110, 40)
        Button1.TabIndex = 12
        Button1.Text = "Capturar"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' btnatras
        ' 
        btnatras.Location = New Point(31, 297)
        btnatras.Name = "btnatras"
        btnatras.Size = New Size(75, 23)
        btnatras.TabIndex = 13
        btnatras.Text = "Atras"
        btnatras.UseVisualStyleBackColor = True
        ' 
        ' DataGridView1
        ' 
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Location = New Point(257, 136)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.Size = New Size(505, 101)
        DataGridView1.TabIndex = 14
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(365, 36)
        Label1.Name = "Label1"
        Label1.Size = New Size(217, 32)
        Label1.TabIndex = 15
        Label1.Text = "Captura producto"
        ' 
        ' descripcion
        ' 
        descripcion.FormattingEnabled = True
        descripcion.Items.AddRange(New Object() {"205/55 R16", "265/70 R17", "225/45 ZR18", "95/65 R15", "245/40 R19", "185/65 R14"})
        descripcion.Location = New Point(12, 139)
        descripcion.Name = "descripcion"
        descripcion.Size = New Size(178, 23)
        descripcion.TabIndex = 16
        ' 
        ' CapturaAl
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), Image)
        ClientSize = New Size(800, 450)
        Controls.Add(descripcion)
        Controls.Add(Label1)
        Controls.Add(DataGridView1)
        Controls.Add(btnatras)
        Controls.Add(Button1)
        Controls.Add(Cantidad)
        Controls.Add(mostrarcantida)
        Controls.Add(mostrarfecha)
        Controls.Add(mostrardescripcion)
        Controls.Add(mostrarnombre)
        Controls.Add(mostraringresaid)
        Controls.Add(Fecha)
        Controls.Add(Nombre)
        Controls.Add(Id)
        Name = "CapturaAl"
        Text = "Capturar"
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Id As ComboBox
    Friend WithEvents Nombre As ComboBox
    Friend WithEvents Fecha As TextBox
    Friend WithEvents mostraringresaid As Label
    Friend WithEvents mostrarnombre As Label
    Friend WithEvents mostrardescripcion As Label
    Friend WithEvents mostrarfecha As Label
    Friend WithEvents mostrarcantida As Label
    Friend WithEvents Cantidad As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents btnatras As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Label1 As Label
    Friend WithEvents descripcion As ComboBox
End Class
