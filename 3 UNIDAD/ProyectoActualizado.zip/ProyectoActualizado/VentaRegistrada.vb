﻿Public Class VentaRegistrada

End Class