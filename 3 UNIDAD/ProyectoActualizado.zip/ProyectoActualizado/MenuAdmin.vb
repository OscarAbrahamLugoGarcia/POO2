﻿Public Class MenuAdmin
    Inherits Form
    Private Sub MenuAdmin_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub LblTitulo_Click(sender As Object, e As EventArgs) Handles lblTitulo.Click

    End Sub

    Private Sub BtnRevisarStock_Click(sender As Object, e As EventArgs) Handles btnRevisarStock.Click
        Dim ventanaStock As New RevisarStockForm()
        ventanaStock.Show()
    End Sub

    Private Sub BtnAbastecer_Click(sender As Object, e As EventArgs) Handles btnAbastecer.Click
        Dim ventanaAbastecer As New AbastecerForm()
        ventanaAbastecer.Show()
    End Sub

    Private Sub btnBajaRotacion_Click(sender As Object, e As EventArgs) Handles btnBajaRotacion.Click
        Dim ventanaRotacion As New BajaRotacionForm()
        ventanaRotacion.Show()
    End Sub

    Private Sub btnOrdenCompra_Click(sender As Object, e As EventArgs) Handles btnOrdenCompra.Click
        Dim ventanaCompra As New OrdenCompraForm()
        ventanaCompra.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
        Menuinicial.Show()
    End Sub
End Class