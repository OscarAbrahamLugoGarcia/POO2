﻿Public Class PedidosAl
    Private Sub PedidosAl_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DataGridView1.ColumnCount = 5
        DataGridView1.Columns(0).Name = "ID"
        DataGridView1.Columns(1).Name = "Nombre"
        DataGridView1.Columns(4).Name = "Cantidad"
        DataGridView1.Columns(3).Name = "Fecha"


    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged

    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox2.SelectedIndexChanged

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim idProducto As String = ComboBox1.Text
        Dim nombreProducto As String = ComboBox2.Text
        Dim cantidad As String = TextBox1.Text
        Dim fecha As String = TextBox2.Text

        ' Validar campos vacíos
        If idProducto = "" Or nombreProducto = "" Or cantidad = "" Or fecha = "" Then
            MessageBox.Show("Por favor completa todos los campos.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        ' Validar que la cantidad sea numérica y positiva
        If Not IsNumeric(cantidad) Or Val(cantidad) <= 0 Then
            MessageBox.Show("La cantidad debe ser un número válido mayor que cero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        ' Agregar al DataGridView (asegúrate de tenerlo creado en el formulario)
        DataGridView1.Rows.Add(idProducto, nombreProducto, "Pedido", fecha, cantidad)

        ' Guardar en archivo de texto
        Dim rutaArchivo As String = "AlmacenVB.txt"
        Dim linea As String = $"[{fecha}] Pedido - ID Producto: {idProducto}, Nombre: {nombreProducto}, Cantidad: {cantidad}"
        My.Computer.FileSystem.WriteAllText(rutaArchivo, linea & vbCrLf, True)

        ' Abrir el bloc de notas
        Process.Start("notepad.exe", rutaArchivo)

        ' Limpiar campos
        ComboBox1.SelectedIndex = -1
        ComboBox2.SelectedIndex = -1
        TextBox1.Clear()
        TextBox2.Clear()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click

    End Sub
End Class