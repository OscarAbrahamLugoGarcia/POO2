﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MenuAdmin
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        lblTitulo = New Label()
        btnRevisarStock = New Button()
        btnAbastecer = New Button()
        btnBajaRotacion = New Button()
        btnOrdenCompra = New Button()
        Button1 = New Button()
        SuspendLayout()
        ' 
        ' lblTitulo
        ' 
        lblTitulo.AutoSize = True
        lblTitulo.BackColor = SystemColors.ActiveCaption
        lblTitulo.Font = New Font("Segoe Print", 24F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTitulo.Location = New Point(216, 26)
        lblTitulo.Name = "lblTitulo"
        lblTitulo.Size = New Size(268, 57)
        lblTitulo.TabIndex = 0
        lblTitulo.Text = "Menú Principal"
        ' 
        ' btnRevisarStock
        ' 
        btnRevisarStock.BackColor = SystemColors.InactiveCaption
        btnRevisarStock.Font = New Font("Segoe Print", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnRevisarStock.Location = New Point(188, 118)
        btnRevisarStock.Margin = New Padding(3, 2, 3, 2)
        btnRevisarStock.Name = "btnRevisarStock"
        btnRevisarStock.Size = New Size(150, 30)
        btnRevisarStock.TabIndex = 1
        btnRevisarStock.Text = "Revisar Stock"
        btnRevisarStock.UseVisualStyleBackColor = False
        ' 
        ' btnAbastecer
        ' 
        btnAbastecer.BackColor = SystemColors.InactiveCaption
        btnAbastecer.Font = New Font("Segoe Print", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnAbastecer.Location = New Point(188, 186)
        btnAbastecer.Margin = New Padding(3, 2, 3, 2)
        btnAbastecer.Name = "btnAbastecer"
        btnAbastecer.Size = New Size(150, 30)
        btnAbastecer.TabIndex = 2
        btnAbastecer.Text = "Abastecer"
        btnAbastecer.UseVisualStyleBackColor = False
        ' 
        ' btnBajaRotacion
        ' 
        btnBajaRotacion.BackColor = SystemColors.InactiveCaption
        btnBajaRotacion.Font = New Font("Segoe Print", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnBajaRotacion.Location = New Point(392, 118)
        btnBajaRotacion.Margin = New Padding(3, 2, 3, 2)
        btnBajaRotacion.Name = "btnBajaRotacion"
        btnBajaRotacion.Size = New Size(150, 30)
        btnBajaRotacion.TabIndex = 3
        btnBajaRotacion.Text = "Baja Rotación"
        btnBajaRotacion.UseVisualStyleBackColor = False
        ' 
        ' btnOrdenCompra
        ' 
        btnOrdenCompra.BackColor = SystemColors.InactiveCaption
        btnOrdenCompra.Font = New Font("Segoe Print", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnOrdenCompra.Location = New Point(392, 186)
        btnOrdenCompra.Margin = New Padding(3, 2, 3, 2)
        btnOrdenCompra.Name = "btnOrdenCompra"
        btnOrdenCompra.Size = New Size(150, 28)
        btnOrdenCompra.TabIndex = 4
        btnOrdenCompra.Text = "Orden de Compra"
        btnOrdenCompra.UseVisualStyleBackColor = False
        ' 
        ' Button1
        ' 
        Button1.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button1.Location = New Point(287, 262)
        Button1.Name = "Button1"
        Button1.Size = New Size(128, 46)
        Button1.TabIndex = 5
        Button1.Text = "Cerrar Sesion"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' MenuAdmin
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(700, 338)
        Controls.Add(Button1)
        Controls.Add(btnOrdenCompra)
        Controls.Add(btnBajaRotacion)
        Controls.Add(btnAbastecer)
        Controls.Add(btnRevisarStock)
        Controls.Add(lblTitulo)
        Margin = New Padding(3, 2, 3, 2)
        Name = "MenuAdmin"
        Text = "MenuAdmin"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lblTitulo As Label
    Friend WithEvents btnRevisarStock As Button
    Friend WithEvents btnAbastecer As Button
    Friend WithEvents btnBajaRotacion As Button
    Friend WithEvents btnOrdenCompra As Button
    Friend WithEvents Button1 As Button
End Class
