﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class BajaRotacionForm
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        lblTitulo = New Label()
        dgvBajaRotacion = New DataGridView()
        btnVolver = New Button()
        CType(dgvBajaRotacion, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' lblTitulo
        ' 
        lblTitulo.AutoSize = True
        lblTitulo.Dock = DockStyle.Top
        lblTitulo.Font = New Font("Showcard Gothic", 16.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        lblTitulo.Location = New Point(0, 0)
        lblTitulo.Name = "lblTitulo"
        lblTitulo.Size = New Size(304, 28)
        lblTitulo.TabIndex = 0
        lblTitulo.Text = "Llantas de Baja Rotación"
        ' 
        ' dgvBajaRotacion
        ' 
        dgvBajaRotacion.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgvBajaRotacion.Dock = DockStyle.Fill
        dgvBajaRotacion.Location = New Point(0, 28)
        dgvBajaRotacion.Margin = New Padding(3, 2, 3, 2)
        dgvBajaRotacion.Name = "dgvBajaRotacion"
        dgvBajaRotacion.ReadOnly = True
        dgvBajaRotacion.RowHeadersWidth = 51
        dgvBajaRotacion.Size = New Size(700, 310)
        dgvBajaRotacion.TabIndex = 1
        ' 
        ' btnVolver
        ' 
        btnVolver.BackColor = Color.IndianRed
        btnVolver.Font = New Font("Palatino Linotype", 13.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        btnVolver.Location = New Point(420, 0)
        btnVolver.Margin = New Padding(3, 2, 3, 2)
        btnVolver.Name = "btnVolver"
        btnVolver.Size = New Size(112, 26)
        btnVolver.TabIndex = 2
        btnVolver.Text = "Volver"
        btnVolver.UseVisualStyleBackColor = False
        ' 
        ' BajaRotacionForm
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(700, 338)
        Controls.Add(btnVolver)
        Controls.Add(dgvBajaRotacion)
        Controls.Add(lblTitulo)
        Margin = New Padding(3, 2, 3, 2)
        Name = "BajaRotacionForm"
        Text = "BajaRotacionForm"
        CType(dgvBajaRotacion, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lblTitulo As Label
    Friend WithEvents dgvBajaRotacion As DataGridView
    Friend WithEvents btnVolver As Button
End Class
