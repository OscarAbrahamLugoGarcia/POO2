﻿Public Class RevisarStockForm
    Inherits Form
    Private Sub RevisarStockForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Crear columnas
        dgvStock.Columns.Add("codigo", "Código")
        dgvStock.Columns.Add("producto", "Producto")
        dgvStock.Columns.Add("cantidad", "Cantidad")
        dgvStock.Columns.Add("ubicacion", "Ubicación")

        ' Agregar filas de ejemplo
        dgvStock.Rows.Add("LL001", "Llantas 14'' Michelin", 20, "Estante A1")
        dgvStock.Rows.Add("LL002", "Llantas 15'' Pirelli", 15, "Estante A2")
        dgvStock.Rows.Add("LL003", "Llantas 16'' Bridgestone", 8, "Estante B1")
        dgvStock.Rows.Add("LL004", "Llantas 17'' Firestone", 6, "Estante B2")
        dgvStock.Rows.Add("LL005", "Llantas 13'' Hankook", 3, "Estante C1")
        dgvStock.Rows.Add("LL006", "Llantas 18'' Goodyear", 25, "Estante D1")
        dgvStock.Rows.Add("LL007", "Llantas 12'' Toyo", 1, "Estante C2")
        dgvStock.Rows.Add("LL008", "Llantas 20'' Continental", 12, "Estante E1")
        dgvStock.Rows.Add("LL009", "Llantas 19'' Dunlop", 10, "Estante E2")
        dgvStock.Rows.Add("LL010", "Llantas 15'' General Tire", 4, "Estante A3")
    End Sub

    Private Sub lblTitulo_Click(sender As Object, e As EventArgs) Handles lblTitulo.Click

    End Sub

    Private Sub dgvStock_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvStock.CellContentClick

    End Sub

    Private Sub btnVolver_Click(sender As Object, e As EventArgs) Handles btnVolver.Click
        Me.Close()
    End Sub
End Class