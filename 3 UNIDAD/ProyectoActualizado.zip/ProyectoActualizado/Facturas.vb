﻿Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Facturas
    Private Sub Label9_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click

    End Sub

    Private Sub Label7_Click(sender As Object, e As EventArgs) Handles Label7.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub Facturas_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub



    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles TextBox5.TextChanged

    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles TextBox3.TextChanged

    End Sub

    Private Sub TextBox7_TextChanged(sender As Object, e As EventArgs) Handles TextBox7.TextChanged

    End Sub

    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs) Handles TextBox4.TextChanged

    End Sub

    Private Sub TextBox8_TextChanged(sender As Object, e As EventArgs) Handles TextBox8.TextChanged

    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox2.SelectedIndexChanged

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim Folio As String = TextBox1.Text
        Dim Nombre As String = TextBox5.Text
        Dim RFC As String = TextBox3.Text
        Dim RazonSocial As String = TextBox7.Text
        Dim DireccionFiscal As String = TextBox4.Text
        Dim Cantidad As String = TextBox8.Text
        Dim FormadePago As String = ComboBox2.Text




        ' Validar campos vacíos
        If Nombre <> "" And Folio <> "" And RFC <> "" And RazonSocial <> "" And DireccionFiscal <> "" And Cantidad <> "" And FormadePago Then
            ' Validar cantidad numérica positiva

            ' Construir línea
            Dim linea As String = $"[] Factura Registrada - Nombre: {Nombre}, Folio: {Folio}, RazonSocial: {RazonSocial}, DireccionFiscal; {DireccionFiscal}, Cantidad: {Cantidad}, RFC: {RFC}"
            Dim rutaArchivo As String = "AlmacenVB.txt"

            Try
                ' Guardar la orden
                My.Computer.FileSystem.WriteAllText(rutaArchivo, linea & vbCrLf, append:=True)

                ' Mostrar mensaje
                MessageBox.Show("Cliente registrado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information)

                ' Abrir bloc de notas con el archivo
                Process.Start("notepad.exe", rutaArchivo)
            Catch ex As Exception
                MessageBox.Show("Error al guardar la Venta: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            ' Limpiar campos
            TextBox1.Clear()
            TextBox5.Clear()
            TextBox7.Clear()
            TextBox4.Clear()
            TextBox8.Clear()
            TextBox3.Clear()
            ComboBox2.SelectedIndex = -1
        Else
            MessageBox.Show("Por favor completa todos los campos.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

    End Sub
End Class