﻿Public Class OrdenCompraForm
    Inherits Form
    Private Sub OrdenCompraForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Códigos de productos
        cmbCodigo.Items.Add("LL001")
        cmbCodigo.Items.Add("LL002")
        cmbCodigo.Items.Add("LL003")
        cmbCodigo.Items.Add("LL004")
        cmbCodigo.Items.Add("LL005")
        cmbCodigo.Items.Add("LL006")
        cmbCodigo.Items.Add("LL007")
        cmbCodigo.Items.Add("LL008")
        cmbCodigo.Items.Add("LL009")
        cmbCodigo.Items.Add("LL010")
        cmbCodigo.Items.Add("LL011")
        cmbCodigo.Items.Add("LL012")
        cmbCodigo.Items.Add("LL013")
        cmbCodigo.Items.Add("LL014")
        cmbCodigo.Items.Add("LL015")
        cmbCodigo.Items.Add("LL016")

        ' Productos
        cmbProducto.Items.Add("Llantas 14'' Michelin")
        cmbProducto.Items.Add("Llantas 15'' Pirelli")
        cmbProducto.Items.Add("Llantas 16'' Bridgestone")
        cmbProducto.Items.Add("Llantas 17'' Firestone")
        cmbProducto.Items.Add("Llantas 13'' Hankook")
        cmbProducto.Items.Add("Llantas 18'' Goodyear")
        cmbProducto.Items.Add("Llantas 12'' Toyo")
        cmbProducto.Items.Add("Llantas 20'' Continental")
        cmbProducto.Items.Add("Llantas 19'' Dunlop")
        cmbProducto.Items.Add("Llantas 15'' General Tire")
        cmbProducto.Items.Add("Llantas 19'' WestLake")
        cmbProducto.Items.Add("Llantas 16'' Nexen")
        cmbProducto.Items.Add("Llantas 17'' Kumho")
        cmbProducto.Items.Add("Llantas 20'' LingLong")
        cmbProducto.Items.Add("Llantas 14'' Giti")
        cmbProducto.Items.Add("Llantas 12'' Maxxis")

        ' Proveedores
        cmbProveedor.Items.Add("Distribuidora El Llantón")
        cmbProveedor.Items.Add("AutoPartes México")
        cmbProveedor.Items.Add("Llantas y Más")
        cmbProveedor.Items.Add("Mayoristas Firestone")
        cmbProveedor.Items.Add("Proveedor Hankook")
        cmbProveedor.Items.Add("Neumáticos del Norte")

        ' Vaciar selección al inicio
        cmbCodigo.SelectedIndex = -1
        cmbProducto.SelectedIndex = -1
        cmbProveedor.SelectedIndex = -1
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub txtCantidad_TextChanged(sender As Object, e As EventArgs) Handles txtCantidad.TextChanged

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub


    Private Sub btnEnviar_Click(sender As Object, e As EventArgs) Handles btnEnviar.Click
        Dim proveedor As String = cmbProveedor.Text
        Dim producto As String = cmbProducto.Text
        Dim cantidad As String = txtCantidad.Text
        Dim fecha As String = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")

        ' Validar campos vacíos
        If proveedor = "" Or producto = "" Or cantidad = "" Then
            MessageBox.Show("Por favor completa todos los campos.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        ' Validar cantidad numérica positiva
        If Not IsNumeric(cantidad) Or Val(cantidad) <= 0 Then
            MessageBox.Show("La cantidad debe ser un número válido mayor que cero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        ' Construir línea
        Dim linea As String = $"[{fecha}] Orden de Compra - Proveedor: {proveedor}, Producto: {producto}, Cantidad: {cantidad}"
        Dim rutaArchivo As String = "AlmacenVB.txt"

        Try
            ' Guardar la orden
            My.Computer.FileSystem.WriteAllText(rutaArchivo, linea & vbCrLf, append:=True)

            ' Mostrar mensaje
            MessageBox.Show("Orden de compra registrada correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information)

            ' Abrir bloc de notas con el archivo
            Process.Start("notepad.exe", rutaArchivo)
        Catch ex As Exception
            MessageBox.Show("Error al guardar la orden: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        ' Limpiar campos
        cmbProveedor.SelectedIndex = -1
        cmbProducto.SelectedIndex = -1
        txtCantidad.Clear()
    End Sub

    Private Sub btnVolver_Click(sender As Object, e As EventArgs) Handles btnVolver.Click
        Me.Close()
    End Sub

    Private Sub cmbCodigo_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbCodigo.SelectedIndexChanged

    End Sub

    Private Sub cmbProducto_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbProducto.SelectedIndexChanged

    End Sub

    Private Sub cmbProveedor_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbProveedor.SelectedIndexChanged

    End Sub
End Class