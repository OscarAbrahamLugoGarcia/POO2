﻿Public Class OpcionesAl
    Private Sub Opciones_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    '''''''''''''''''''Menu de inicio
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles txtmenu.Click

    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles txtopciones.Enter

    End Sub


    ''''''''Opciones a elegir
    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged

    End Sub
    'Botones
    Private Sub Btncontinuar_Click(sender As Object, e As EventArgs) Handles btncontinuar.Click
        Select Case ComboBox1.SelectedItem
            Case "Consultar"
                ConsultasAl.Show()
            Case "Capturar"
                CapturaAl.Show()
            Case "Pedidos"
                PedidosAl.Show()
            Case "Modificar"
                LoginModificarAl.Show()

            Case Else
                MessageBox.Show("Por favor, selecciona una opción válida del ComboBox.")
        End Select
    End Sub

    Private Sub Btncerrarsesion_Click(sender As Object, e As EventArgs) Handles btncerrarsesion.Click
        Me.Close()
        Menuinicial.Show()
    End Sub
End Class