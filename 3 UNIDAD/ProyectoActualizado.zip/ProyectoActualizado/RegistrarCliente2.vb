﻿Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class RegistrarCliente
    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub RegistrarCliente_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub


    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles TextBox3.TextChanged

    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles TextBox5.TextChanged

    End Sub

    Private Sub TextBox8_TextChanged(sender As Object, e As EventArgs) Handles TextBox8.TextChanged

    End Sub

    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs) Handles TextBox4.TextChanged

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim Nombres As String = TextBox1.Text
        Dim Apellido As String = TextBox2.Text
        Dim Direccion As String = TextBox3.Text
        Dim Telefono As String = TextBox4.Text
        Dim Correo As String = TextBox5.Text
        Dim RFC As String = TextBox8.Text
        Dim Fecha As Date = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")



        ' Validar campos vacíos
        If Nombres <> "" And Apellido <> "" And Direccion <> "" And Telefono <> "" And Correo <> "" And RFC Then
            ' Validar cantidad numérica positiva

            ' Construir línea
            Dim linea As String = $"[{Fecha}] Cliente Registrada - Nombres: {Nombres}, Apellido: {Apellido}, Direccion: {Direccion}, Telefono; {Telefono}, Correo: {Correo}, RFC: {RFC}"
            Dim rutaArchivo As String = "AlmacenVB.txt"

            Try
                ' Guardar la orden
                My.Computer.FileSystem.WriteAllText(rutaArchivo, linea & vbCrLf, append:=True)

                ' Mostrar mensaje
                MessageBox.Show("Cliente registrado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information)

                ' Abrir bloc de notas con el archivo
                Process.Start("notepad.exe", rutaArchivo)
            Catch ex As Exception
                MessageBox.Show("Error al guardar la Venta: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            ' Limpiar campos
            TextBox1.Clear()
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox4.Clear()
            TextBox8.Clear()
            TextBox5.Clear()
        Else
            MessageBox.Show("Por favor completa todos los campos.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

    End Sub
End Class