﻿Imports System.IO

Public Class CompraLlantas
    Private Sub Form7_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Comprobante.Show()
        For i As Integer = 0 To Llantas1.ListaNombres.Count - 1
            Llantas1.ActualizarStockYGuardar(Llantas1.ListaNombres(i), Llantas1.ListaDescripciones(i), Llantas1.ListaCantidades(i))
        Next

        ' Limpiar listas temporales después de procesar
        Llantas1.ListaNombres.Clear()
        Llantas1.ListaDescripciones.Clear()
        Llantas1.ListaCantidades.Clear()

        ' Abrir archivos para revisar cambios

        'Dim rutaDatos As String = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "DatosSeparados.txt")
        'Process.Start("notepad.exe", rutaDatos)

        MessageBox.Show("Compra realizada y stock actualizado.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub



    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged


    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub
End Class


