﻿Public Class RegistrarProducto
    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim IdProducto As String = TextBox1.Text
        Dim Cantidad As String = TextBox6.Text
        Dim Descripcion As String = TextBox2.Text
        Dim FechaIngreso As Date = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")
        Dim Precio As Decimal
        Dim Proveedor As String = TextBox5.Text



        ' Validar campos vacíos
        If IdProducto <> "" And Cantidad <> "" And Descripcion <> "" And Proveedor <> "" Then
            ' Validar cantidad numérica positiva
            If Not IsNumeric(Cantidad) Or Val(Cantidad) <= 0 Then
                MessageBox.Show("La cantidad debe ser un número válido mayor que cero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            ' Construir línea
            Dim linea As String = $"[{FechaIngreso}] Venta Registrada - IdProducto: {IdProducto}, Cantidad: {Cantidad}, Descripcion: {Descripcion}, FechaIngreso; {FechaIngreso}, Precio: {Precio}, Proveedor: {Proveedor}"
            Dim rutaArchivo As String = "AlmacenVB.txt"

            Try
                ' Guardar la orden
                My.Computer.FileSystem.WriteAllText(rutaArchivo, linea & vbCrLf, append:=True)

                ' Mostrar mensaje
                MessageBox.Show("Producto registrado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information)

                ' Abrir bloc de notas con el archivo
                Process.Start("notepad.exe", rutaArchivo)
            Catch ex As Exception
                MessageBox.Show("Error al guardar la Venta: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            ' Limpiar campos
            TextBox1.Clear()
            TextBox2.Clear()
            TextBox6.Clear()
            TextBox5.Clear()
        Else
            MessageBox.Show("Por favor completa todos los campos.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

    End Sub

    Private Sub RegistrarProducto_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub TextBox6_TextChanged(sender As Object, e As EventArgs) Handles TextBox6.TextChanged

    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles TextBox3.TextChanged

    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles TextBox5.TextChanged

    End Sub

    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs) Handles TextBox4.TextChanged

    End Sub
End Class