﻿Imports System.Runtime.InteropServices.JavaScript.JSType
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Imports System.IO
Public Class CapturaAl

    Private Sub CapturaAl_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        DataGridView1.ColumnCount = 5
        DataGridView1.Columns(0).Name = "ID"
        DataGridView1.Columns(1).Name = "Nombre"
        DataGridView1.Columns(2).Name = "Descripción"
        DataGridView1.Columns(3).Name = "Fecha"
        DataGridView1.Columns(4).Name = "Cantidad"

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged_1(sender As Object, e As EventArgs) Handles Id.SelectedIndexChanged

    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Nombre.SelectedIndexChanged

    End Sub
    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs) Handles Fecha.TextChanged

    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles Cantidad.TextChanged

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles mostraringresaid.Click

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles mostrarnombre.Click

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles mostrardescripcion.Click

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles mostrarfecha.Click

    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles mostrarcantida.Click

    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ' Obtener datos desde los controles (ya renombrados)
        Dim valorID As String = Id.Text
        Dim valorNombre As String = Nombre.Text
        Dim valorDescripcion As String = Descripcion.Text
        Dim valorFecha As String = Fecha.Text
        Dim valorCantidad As String = Cantidad.Text

        ' Rutas de los archivos en el escritorio
        Dim ruta1 As String = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "AlmacenVB.txt")
        Dim ruta2 As String = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "DatosSeparados.txt")

        ' -----------------------
        ' 1. Guardar en AlmacenVB.txt (formato detallado)
        ' -----------------------
        Dim contenido1 As String = "Id: " & valorID & Environment.NewLine &
                                   "Nombre: " & valorNombre & Environment.NewLine &
                                   "Descripcion: " & valorDescripcion & Environment.NewLine &
                                   "Fecha: " & valorFecha & Environment.NewLine &
                                   "Cantidad: " & valorCantidad & Environment.NewLine &
                                   "-----------------------------" & Environment.NewLine
        File.AppendAllText(ruta1, contenido1)

        ' -----------------------
        ' 2. Guardar en DatosSeparados.txt (formato en una sola línea con comas)
        ' -----------------------
        Dim contenido2 As String = "Id:" & valorID & ", Nombre:" & valorNombre & ", Descripcion:" & valorDescripcion & ", Fecha:" & valorFecha & ", Cantidad:" & valorCantidad & "," & Environment.NewLine
        File.AppendAllText(ruta2, contenido2)

        ' Abrir automáticamente ambos archivos en el bloc de notas
        Process.Start("notepad.exe", ruta1)
        Process.Start("notepad.exe", ruta2)

        ' Mensaje de confirmación
        MessageBox.Show("Datos guardados y ambos archivos abiertos.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Id.Text = " "
        Nombre.Text = " "
        descripcion.Text = " "
        Fecha.Text = " "
        Cantidad.Text = " "

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnatras.Click
        Me.Close()

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub Label1_Click_1(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
End Class