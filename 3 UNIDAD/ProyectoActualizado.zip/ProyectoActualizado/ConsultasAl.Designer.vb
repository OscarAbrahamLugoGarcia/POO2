﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class ConsultasAl
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ConsultasAl))
        mostraringresaid = New Label()
        txtbuscar = New TextBox()
        btnbuscar = New Button()
        btnatras = New Button()
        dgvStock = New DataGridView()
        CType(dgvStock, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' mostraringresaid
        ' 
        mostraringresaid.AutoSize = True
        mostraringresaid.Font = New Font("Segoe UI", 12.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        mostraringresaid.Location = New Point(344, 13)
        mostraringresaid.Name = "mostraringresaid"
        mostraringresaid.Size = New Size(87, 21)
        mostraringresaid.TabIndex = 0
        mostraringresaid.Text = "Ingresa ID"
        ' 
        ' txtbuscar
        ' 
        txtbuscar.Location = New Point(294, 37)
        txtbuscar.Name = "txtbuscar"
        txtbuscar.Size = New Size(169, 23)
        txtbuscar.TabIndex = 1
        ' 
        ' btnbuscar
        ' 
        btnbuscar.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnbuscar.Location = New Point(493, 37)
        btnbuscar.Name = "btnbuscar"
        btnbuscar.Size = New Size(75, 23)
        btnbuscar.TabIndex = 2
        btnbuscar.Text = "Buscar"
        btnbuscar.UseVisualStyleBackColor = True
        ' 
        ' btnatras
        ' 
        btnatras.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnatras.Location = New Point(29, 276)
        btnatras.Name = "btnatras"
        btnatras.Size = New Size(75, 23)
        btnatras.TabIndex = 3
        btnatras.Text = "Atras"
        btnatras.UseVisualStyleBackColor = True
        ' 
        ' dgvStock
        ' 
        dgvStock.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgvStock.Location = New Point(180, 112)
        dgvStock.Name = "dgvStock"
        dgvStock.Size = New Size(500, 187)
        dgvStock.TabIndex = 4
        ' 
        ' Consultas
        ' 
        AutoScaleDimensions = New SizeF(7.0F, 15.0F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), Image)
        ClientSize = New Size(800, 450)
        Controls.Add(dgvStock)
        Controls.Add(btnatras)
        Controls.Add(btnbuscar)
        Controls.Add(txtbuscar)
        Controls.Add(mostraringresaid)
        Name = "Consultas"
        Text = "consultar"
        CType(dgvStock, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents mostraringresaid As Label
    Friend WithEvents txtbuscar As TextBox
    Friend WithEvents btnbuscar As Button
    Friend WithEvents btnatras As Button
    Friend WithEvents dgvStock As DataGridView
End Class
