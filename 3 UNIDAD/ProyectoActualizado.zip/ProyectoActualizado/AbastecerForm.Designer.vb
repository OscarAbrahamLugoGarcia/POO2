﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AbastecerForm
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        txtCantidad = New TextBox()
        btnGuardar = New Button()
        btnVolver = New Button()
        cmbCodigo = New ComboBox()
        cmbProducto = New ComboBox()
        cmbUbicacion = New ComboBox()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.FromArgb(CByte(255), CByte(192), CByte(192))
        Label1.Font = New Font("Palatino Linotype", 16.2F, FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(117, 55)
        Label1.Name = "Label1"
        Label1.Size = New Size(200, 29)
        Label1.TabIndex = 0
        Label1.Text = "Código del Producto:"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.FromArgb(CByte(255), CByte(192), CByte(192))
        Label2.Font = New Font("Palatino Linotype", 13.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(123, 94)
        Label2.Name = "Label2"
        Label2.Size = New Size(197, 26)
        Label2.TabIndex = 1
        Label2.Text = "Nombre del Producto:"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = Color.FromArgb(CByte(255), CByte(192), CByte(192))
        Label3.Font = New Font("Palatino Linotype", 13.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(235, 136)
        Label3.Name = "Label3"
        Label3.Size = New Size(91, 26)
        Label3.TabIndex = 2
        Label3.Text = "Cantidad:"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.BackColor = Color.FromArgb(CByte(255), CByte(192), CByte(192))
        Label4.Font = New Font("Palatino Linotype", 13.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(228, 173)
        Label4.Name = "Label4"
        Label4.Size = New Size(99, 26)
        Label4.TabIndex = 3
        Label4.Text = "Ubicación:"
        ' 
        ' txtCantidad
        ' 
        txtCantidad.Font = New Font("Palatino Linotype", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtCantidad.ForeColor = Color.RosyBrown
        txtCantidad.Location = New Point(360, 136)
        txtCantidad.Margin = New Padding(3, 2, 3, 2)
        txtCantidad.Name = "txtCantidad"
        txtCantidad.Size = New Size(123, 29)
        txtCantidad.TabIndex = 6
        ' 
        ' btnGuardar
        ' 
        btnGuardar.BackColor = SystemColors.ActiveCaption
        btnGuardar.Font = New Font("Palatino Linotype", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        btnGuardar.Location = New Point(538, 290)
        btnGuardar.Margin = New Padding(3, 2, 3, 2)
        btnGuardar.Name = "btnGuardar"
        btnGuardar.Size = New Size(112, 30)
        btnGuardar.TabIndex = 8
        btnGuardar.Text = "Guardar"
        btnGuardar.UseVisualStyleBackColor = False
        ' 
        ' btnVolver
        ' 
        btnVolver.BackColor = SystemColors.ActiveCaption
        btnVolver.Font = New Font("Palatino Linotype", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        btnVolver.Location = New Point(429, 290)
        btnVolver.Margin = New Padding(3, 2, 3, 2)
        btnVolver.Name = "btnVolver"
        btnVolver.Size = New Size(92, 30)
        btnVolver.TabIndex = 9
        btnVolver.Text = "Volver"
        btnVolver.UseVisualStyleBackColor = False
        ' 
        ' cmbCodigo
        ' 
        cmbCodigo.Font = New Font("Palatino Linotype", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        cmbCodigo.ForeColor = Color.RosyBrown
        cmbCodigo.FormattingEnabled = True
        cmbCodigo.Location = New Point(360, 55)
        cmbCodigo.Margin = New Padding(3, 2, 3, 2)
        cmbCodigo.Name = "cmbCodigo"
        cmbCodigo.Size = New Size(123, 30)
        cmbCodigo.TabIndex = 10
        ' 
        ' cmbProducto
        ' 
        cmbProducto.Font = New Font("Palatino Linotype", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        cmbProducto.ForeColor = Color.RosyBrown
        cmbProducto.FormattingEnabled = True
        cmbProducto.Location = New Point(360, 94)
        cmbProducto.Margin = New Padding(3, 2, 3, 2)
        cmbProducto.Name = "cmbProducto"
        cmbProducto.Size = New Size(161, 30)
        cmbProducto.TabIndex = 11
        ' 
        ' cmbUbicacion
        ' 
        cmbUbicacion.Font = New Font("Palatino Linotype", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        cmbUbicacion.ForeColor = Color.RosyBrown
        cmbUbicacion.FormattingEnabled = True
        cmbUbicacion.Location = New Point(360, 173)
        cmbUbicacion.Margin = New Padding(3, 2, 3, 2)
        cmbUbicacion.Name = "cmbUbicacion"
        cmbUbicacion.Size = New Size(123, 30)
        cmbUbicacion.TabIndex = 12
        ' 
        ' AbastecerForm
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(700, 338)
        Controls.Add(cmbUbicacion)
        Controls.Add(cmbProducto)
        Controls.Add(cmbCodigo)
        Controls.Add(btnVolver)
        Controls.Add(btnGuardar)
        Controls.Add(txtCantidad)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Margin = New Padding(3, 2, 3, 2)
        Name = "AbastecerForm"
        Text = "AbastecerForm"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents txtCantidad As TextBox
    Friend WithEvents btnGuardar As Button
    Friend WithEvents btnVolver As Button
    Friend WithEvents cmbCodigo As ComboBox
    Friend WithEvents cmbProducto As ComboBox
    Friend WithEvents cmbUbicacion As ComboBox
End Class
