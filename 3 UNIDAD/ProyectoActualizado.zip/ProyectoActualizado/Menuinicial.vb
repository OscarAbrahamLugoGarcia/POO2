﻿Public Class Menuinicial
    Private Sub Menuinicial_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub



    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles mostrarusuario.Click

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles mostrarcontrasena.Click

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txtusuario.TextChanged

    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles txtcontrasena.TextChanged

    End Sub



    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btncontinuar.Click
        Dim usuario, password As String


        usuario = txtusuario.Text
        password = txtcontrasena.Text

        txtusuario.Text = ""
        txtcontrasena.Text = ""

        If (usuario = "Kangee") And (password = "1234") Then
            OpcionesAl.Show()
            Me.Hide()

        ElseIf usuario = "Vendedor" And password = "2222" Then
            Me.Hide()
            Opciones.Show()

        ElseIf usuario = "Admin" And password = "1111" Then
            Me.Hide()
            MenuAdmin.Show()

        ElseIf usuario = "Comprador" And password = "3333" Then
            Me.Hide()
            OpcionesComprar.Show()



        Else
            MsgBox("Los datos ingresados son incorrectos")
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnlimpiar.Click
        txtusuario.Text = ""
        txtcontrasena.Text = ""
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btncancelar.Click
        Me.Close()
    End Sub
End Class