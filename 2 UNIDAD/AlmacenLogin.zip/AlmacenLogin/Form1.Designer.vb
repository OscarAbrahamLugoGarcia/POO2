﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Label1 = New Label()
        GroupBox1 = New GroupBox()
        btncancelar = New Button()
        btnlimpiar = New Button()
        btncontinuar = New Button()
        txtcontrasena = New TextBox()
        txtusuario = New TextBox()
        mostrarcontrasena = New Label()
        mostrarusuario = New Label()
        GroupBox1.SuspendLayout()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(370, 29)
        Label1.Name = "Label1"
        Label1.Size = New Size(148, 25)
        Label1.TabIndex = 0
        Label1.Text = "Inicio de sesion"
        ' 
        ' GroupBox1
        ' 
        GroupBox1.BackgroundImage = CType(resources.GetObject("GroupBox1.BackgroundImage"), Image)
        GroupBox1.Controls.Add(btncancelar)
        GroupBox1.Controls.Add(btnlimpiar)
        GroupBox1.Controls.Add(btncontinuar)
        GroupBox1.Controls.Add(txtcontrasena)
        GroupBox1.Controls.Add(txtusuario)
        GroupBox1.Controls.Add(mostrarcontrasena)
        GroupBox1.Controls.Add(mostrarusuario)
        GroupBox1.Font = New Font("Segoe UI", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        GroupBox1.Location = New Point(168, 59)
        GroupBox1.Name = "GroupBox1"
        GroupBox1.Size = New Size(495, 228)
        GroupBox1.TabIndex = 1
        GroupBox1.TabStop = False
        GroupBox1.Text = "Ingresa los datos"
        ' 
        ' btncancelar
        ' 
        btncancelar.Location = New Point(18, 199)
        btncancelar.Name = "btncancelar"
        btncancelar.Size = New Size(75, 23)
        btncancelar.TabIndex = 6
        btncancelar.Text = "Cerrar"
        btncancelar.UseVisualStyleBackColor = True
        ' 
        ' btnlimpiar
        ' 
        btnlimpiar.Location = New Point(390, 83)
        btnlimpiar.Name = "btnlimpiar"
        btnlimpiar.Size = New Size(75, 23)
        btnlimpiar.TabIndex = 5
        btnlimpiar.Text = "Limpiar"
        btnlimpiar.UseVisualStyleBackColor = True
        ' 
        ' btncontinuar
        ' 
        btncontinuar.Location = New Point(390, 190)
        btncontinuar.Name = "btncontinuar"
        btncontinuar.Size = New Size(75, 23)
        btncontinuar.TabIndex = 4
        btncontinuar.Text = "Continar"
        btncontinuar.UseVisualStyleBackColor = True
        ' 
        ' txtcontrasena
        ' 
        txtcontrasena.Location = New Point(167, 116)
        txtcontrasena.Name = "txtcontrasena"
        txtcontrasena.PasswordChar = "*"c
        txtcontrasena.Size = New Size(123, 23)
        txtcontrasena.TabIndex = 3
        ' 
        ' txtusuario
        ' 
        txtusuario.Location = New Point(167, 61)
        txtusuario.Name = "txtusuario"
        txtusuario.Size = New Size(123, 23)
        txtusuario.TabIndex = 2
        ' 
        ' mostrarcontrasena
        ' 
        mostrarcontrasena.AutoSize = True
        mostrarcontrasena.Font = New Font("Segoe UI", 12.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        mostrarcontrasena.Location = New Point(18, 118)
        mostrarcontrasena.Name = "mostrarcontrasena"
        mostrarcontrasena.Size = New Size(96, 21)
        mostrarcontrasena.TabIndex = 1
        mostrarcontrasena.Text = "Contraseña"
        ' 
        ' mostrarusuario
        ' 
        mostrarusuario.AutoSize = True
        mostrarusuario.Font = New Font("Segoe UI", 12.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        mostrarusuario.Location = New Point(26, 61)
        mostrarusuario.Name = "mostrarusuario"
        mostrarusuario.Size = New Size(69, 21)
        mostrarusuario.TabIndex = 0
        mostrarusuario.Text = "Usuario"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7.0F, 15.0F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), Image)
        ClientSize = New Size(800, 450)
        Controls.Add(GroupBox1)
        Controls.Add(Label1)
        Name = "Form1"
        Text = "Menu"
        GroupBox1.ResumeLayout(False)
        GroupBox1.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents btncancelar As Button
    Friend WithEvents btnlimpiar As Button
    Friend WithEvents btncontinuar As Button
    Friend WithEvents txtcontrasena As TextBox
    Friend WithEvents txtusuario As TextBox
    Friend WithEvents mostrarcontrasena As Label
    Friend WithEvents mostrarusuario As Label
End Class
