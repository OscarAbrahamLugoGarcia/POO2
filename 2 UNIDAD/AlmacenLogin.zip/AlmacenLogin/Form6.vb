﻿Public Class Form6
    Private Sub Form6_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub mostrarusuario_Click(sender As Object, e As EventArgs) Handles mostrarusuario.Click

    End Sub

    Private Sub mostrarcontrasena_Click(sender As Object, e As EventArgs) Handles mostrarcontrasena.Click

    End Sub

    Private Sub txtusuario_TextChanged(sender As Object, e As EventArgs) Handles txtusuario.TextChanged

    End Sub

    Private Sub txtcontrasena_TextChanged(sender As Object, e As EventArgs) Handles txtcontrasena.TextChanged

    End Sub

    Private Sub btncontinuar_Click(sender As Object, e As EventArgs) Handles btncontinuar.Click
        Dim usuario, password As String


        usuario = txtusuario.Text
        password = txtcontrasena.Text

        txtusuario.Text = ""
        txtcontrasena.Text = ""

        If (usuario = "Kangee") And (password = "4321") Then
            Form7.Show()
            Me.Hide()



        Else
            MsgBox("Los datos ingresados son incorrectos")
        End If
    End Sub

    Private Sub btnlimpiar_Click(sender As Object, e As EventArgs) Handles btnlimpiar.Click

        txtusuario.Text = ""
        txtcontrasena.Text = ""
    End Sub

    Private Sub btncancelar_Click(sender As Object, e As EventArgs) Handles btncancelar.Click
        Me.Close()
    End Sub
End Class