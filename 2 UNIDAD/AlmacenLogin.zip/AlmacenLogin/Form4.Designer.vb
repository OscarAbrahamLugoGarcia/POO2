﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form4))
        ComboBox1 = New ComboBox()
        ComboBox2 = New ComboBox()
        TextBox3 = New TextBox()
        TextBox4 = New TextBox()
        mostraringresaid = New Label()
        mostrarnombre = New Label()
        mostrardescripcion = New Label()
        mostrarfecha = New Label()
        mostrarcantida = New Label()
        TextBox5 = New TextBox()
        Button1 = New Button()
        btnatras = New Button()
        DataGridView1 = New DataGridView()
        Label1 = New Label()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' ComboBox1
        ' 
        ComboBox1.FormattingEnabled = True
        ComboBox1.Items.AddRange(New Object() {"1", "2", "3", "4"})
        ComboBox1.Location = New Point(12, 30)
        ComboBox1.Name = "ComboBox1"
        ComboBox1.Size = New Size(178, 23)
        ComboBox1.TabIndex = 0
        ' 
        ' ComboBox2
        ' 
        ComboBox2.FormattingEnabled = True
        ComboBox2.Items.AddRange(New Object() {"Michelin", "Bridgestone", "Goodyear", "Continental"})
        ComboBox2.Location = New Point(12, 86)
        ComboBox2.Name = "ComboBox2"
        ComboBox2.Size = New Size(178, 23)
        ComboBox2.TabIndex = 1
        ' 
        ' TextBox3
        ' 
        TextBox3.Location = New Point(12, 139)
        TextBox3.Name = "TextBox3"
        TextBox3.Size = New Size(178, 23)
        TextBox3.TabIndex = 4
        ' 
        ' TextBox4
        ' 
        TextBox4.Location = New Point(12, 192)
        TextBox4.Name = "TextBox4"
        TextBox4.Size = New Size(178, 23)
        TextBox4.TabIndex = 5
        ' 
        ' mostraringresaid
        ' 
        mostraringresaid.AutoSize = True
        mostraringresaid.Location = New Point(22, 12)
        mostraringresaid.Name = "mostraringresaid"
        mostraringresaid.Size = New Size(59, 15)
        mostraringresaid.TabIndex = 6
        mostraringresaid.Text = "Ingresa ID"
        ' 
        ' mostrarnombre
        ' 
        mostrarnombre.AutoSize = True
        mostrarnombre.Location = New Point(14, 68)
        mostrarnombre.Name = "mostrarnombre"
        mostrarnombre.Size = New Size(51, 15)
        mostrarnombre.TabIndex = 7
        mostrarnombre.Text = "Nombre"
        ' 
        ' mostrardescripcion
        ' 
        mostrardescripcion.AutoSize = True
        mostrardescripcion.Location = New Point(12, 121)
        mostrardescripcion.Name = "mostrardescripcion"
        mostrardescripcion.Size = New Size(69, 15)
        mostrardescripcion.TabIndex = 8
        mostrardescripcion.Text = "Descripcion"
        ' 
        ' mostrarfecha
        ' 
        mostrarfecha.AutoSize = True
        mostrarfecha.Location = New Point(14, 174)
        mostrarfecha.Name = "mostrarfecha"
        mostrarfecha.Size = New Size(38, 15)
        mostrarfecha.TabIndex = 9
        mostrarfecha.Text = "Fecha"
        ' 
        ' mostrarcantida
        ' 
        mostrarcantida.AutoSize = True
        mostrarcantida.Location = New Point(12, 228)
        mostrarcantida.Name = "mostrarcantida"
        mostrarcantida.Size = New Size(55, 15)
        mostrarcantida.TabIndex = 10
        mostrarcantida.Text = "Cantidad"
        ' 
        ' TextBox5
        ' 
        TextBox5.Location = New Point(12, 246)
        TextBox5.Name = "TextBox5"
        TextBox5.Size = New Size(178, 23)
        TextBox5.TabIndex = 11
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(687, 297)
        Button1.Name = "Button1"
        Button1.Size = New Size(75, 23)
        Button1.TabIndex = 12
        Button1.Text = "Capturar"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' btnatras
        ' 
        btnatras.Location = New Point(31, 297)
        btnatras.Name = "btnatras"
        btnatras.Size = New Size(75, 23)
        btnatras.TabIndex = 13
        btnatras.Text = "Atras"
        btnatras.UseVisualStyleBackColor = True
        ' 
        ' DataGridView1
        ' 
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Location = New Point(257, 136)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.Size = New Size(505, 101)
        DataGridView1.TabIndex = 14
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(365, 36)
        Label1.Name = "Label1"
        Label1.Size = New Size(217, 32)
        Label1.TabIndex = 15
        Label1.Text = "Captura producto"
        ' 
        ' Form4
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), Image)
        ClientSize = New Size(800, 450)
        Controls.Add(Label1)
        Controls.Add(DataGridView1)
        Controls.Add(btnatras)
        Controls.Add(Button1)
        Controls.Add(TextBox5)
        Controls.Add(mostrarcantida)
        Controls.Add(mostrarfecha)
        Controls.Add(mostrardescripcion)
        Controls.Add(mostrarnombre)
        Controls.Add(mostraringresaid)
        Controls.Add(TextBox4)
        Controls.Add(TextBox3)
        Controls.Add(ComboBox2)
        Controls.Add(ComboBox1)
        Name = "Form4"
        Text = "Capturar"
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents ComboBox2 As ComboBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents mostraringresaid As Label
    Friend WithEvents mostrarnombre As Label
    Friend WithEvents mostrardescripcion As Label
    Friend WithEvents mostrarfecha As Label
    Friend WithEvents mostrarcantida As Label
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents btnatras As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Label1 As Label
End Class
