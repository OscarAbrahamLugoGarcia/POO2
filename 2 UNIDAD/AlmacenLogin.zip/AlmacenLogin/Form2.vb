﻿Public Class Form2
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    '''''''''''''''''''Menu de inicio
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles txtmenu.Click

    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles txtopciones.Enter

    End Sub


    ''''''''Opciones a elegir
    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged

    End Sub
    'Botones
    Private Sub btncontinuar_Click(sender As Object, e As EventArgs) Handles btncontinuar.Click
        Select Case ComboBox1.SelectedItem
            Case "Consultar"
                Form3.Show()
            Case "Capturar"
                Form4.Show()
            Case "Pedidos"
                Form5.Show()
            Case "Modificar"
                Form6.Show()

            Case Else
                MessageBox.Show("Por favor, selecciona una opción válida del ComboBox.")
        End Select
    End Sub

    Private Sub btncerrarsesion_Click(sender As Object, e As EventArgs) Handles btncerrarsesion.Click
        Me.Close()
        Form1.Show()
    End Sub
End Class