﻿Public Class Form4
    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        DataGridView1.ColumnCount = 5
        DataGridView1.Columns(0).Name = "ID"
        DataGridView1.Columns(1).Name = "Nombre"
        DataGridView1.Columns(2).Name = "Descripción"
        DataGridView1.Columns(3).Name = "Fecha"
        DataGridView1.Columns(4).Name = "Cantidad"

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged_1(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged

    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox2.SelectedIndexChanged

    End Sub
    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles TextBox3.TextChanged

    End Sub

    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs) Handles TextBox4.TextChanged

    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles TextBox5.TextChanged

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles mostraringresaid.Click

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles mostrarnombre.Click

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles mostrardescripcion.Click

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles mostrarfecha.Click

    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles mostrarcantida.Click

    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        DataGridView1.Rows.Add(ComboBox1.Text, ComboBox2.Text, TextBox3.Text, TextBox4.Text, TextBox5.Text)

    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnatras.Click
        Me.Close()

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub Label1_Click_1(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
End Class