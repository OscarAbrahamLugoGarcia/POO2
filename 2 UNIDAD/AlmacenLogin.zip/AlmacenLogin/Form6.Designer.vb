﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form6
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form6))
        GroupBox1 = New GroupBox()
        btncancelar = New Button()
        Label1 = New Label()
        btnlimpiar = New Button()
        btncontinuar = New Button()
        txtcontrasena = New TextBox()
        txtusuario = New TextBox()
        mostrarcontrasena = New Label()
        mostrarusuario = New Label()
        GroupBox1.SuspendLayout()
        SuspendLayout()
        ' 
        ' GroupBox1
        ' 
        GroupBox1.BackgroundImage = CType(resources.GetObject("GroupBox1.BackgroundImage"), Image)
        GroupBox1.Controls.Add(btncancelar)
        GroupBox1.Controls.Add(Label1)
        GroupBox1.Controls.Add(btnlimpiar)
        GroupBox1.Controls.Add(btncontinuar)
        GroupBox1.Controls.Add(txtcontrasena)
        GroupBox1.Controls.Add(txtusuario)
        GroupBox1.Controls.Add(mostrarcontrasena)
        GroupBox1.Controls.Add(mostrarusuario)
        GroupBox1.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        GroupBox1.Location = New Point(0, 0)
        GroupBox1.Name = "GroupBox1"
        GroupBox1.Size = New Size(548, 240)
        GroupBox1.TabIndex = 3
        GroupBox1.TabStop = False
        GroupBox1.Text = "Ingresa los datos"
        ' 
        ' btncancelar
        ' 
        btncancelar.Location = New Point(18, 199)
        btncancelar.Name = "btncancelar"
        btncancelar.Size = New Size(75, 23)
        btncancelar.TabIndex = 6
        btncancelar.Text = "Cerrar"
        btncancelar.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(155, 19)
        Label1.Name = "Label1"
        Label1.Size = New Size(148, 25)
        Label1.TabIndex = 2
        Label1.Text = "Inicio de sesion"
        ' 
        ' btnlimpiar
        ' 
        btnlimpiar.Location = New Point(390, 83)
        btnlimpiar.Name = "btnlimpiar"
        btnlimpiar.Size = New Size(75, 23)
        btnlimpiar.TabIndex = 5
        btnlimpiar.Text = "Limpiar"
        btnlimpiar.UseVisualStyleBackColor = True
        ' 
        ' btncontinuar
        ' 
        btncontinuar.Location = New Point(390, 190)
        btncontinuar.Name = "btncontinuar"
        btncontinuar.Size = New Size(75, 23)
        btncontinuar.TabIndex = 4
        btncontinuar.Text = "Continar"
        btncontinuar.UseVisualStyleBackColor = True
        ' 
        ' txtcontrasena
        ' 
        txtcontrasena.Location = New Point(167, 116)
        txtcontrasena.Name = "txtcontrasena"
        txtcontrasena.PasswordChar = "*"c
        txtcontrasena.Size = New Size(123, 23)
        txtcontrasena.TabIndex = 3
        ' 
        ' txtusuario
        ' 
        txtusuario.Location = New Point(167, 61)
        txtusuario.Name = "txtusuario"
        txtusuario.Size = New Size(123, 23)
        txtusuario.TabIndex = 2
        ' 
        ' mostrarcontrasena
        ' 
        mostrarcontrasena.AutoSize = True
        mostrarcontrasena.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        mostrarcontrasena.Location = New Point(18, 118)
        mostrarcontrasena.Name = "mostrarcontrasena"
        mostrarcontrasena.Size = New Size(96, 21)
        mostrarcontrasena.TabIndex = 1
        mostrarcontrasena.Text = "Contraseña"
        ' 
        ' mostrarusuario
        ' 
        mostrarusuario.AutoSize = True
        mostrarusuario.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        mostrarusuario.Location = New Point(26, 61)
        mostrarusuario.Name = "mostrarusuario"
        mostrarusuario.Size = New Size(69, 21)
        mostrarusuario.TabIndex = 0
        mostrarusuario.Text = "Usuario"
        ' 
        ' Form6
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(548, 241)
        Controls.Add(GroupBox1)
        Location = New Point(148, 59)
        Name = "Form6"
        Text = "Modificar"
        GroupBox1.ResumeLayout(False)
        GroupBox1.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents btncancelar As Button
    Friend WithEvents btnlimpiar As Button
    Friend WithEvents btncontinuar As Button
    Friend WithEvents txtcontrasena As TextBox
    Friend WithEvents txtusuario As TextBox
    Friend WithEvents mostrarcontrasena As Label
    Friend WithEvents mostrarusuario As Label
    Friend WithEvents Label1 As Label
End Class
