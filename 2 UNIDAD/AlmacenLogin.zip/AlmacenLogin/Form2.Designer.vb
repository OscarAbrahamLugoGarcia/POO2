﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        txtmenu = New Label()
        txtopciones = New GroupBox()
        btncerrarsesion = New Button()
        btncontinuar = New Button()
        ComboBox1 = New ComboBox()
        txtopciones.SuspendLayout()
        SuspendLayout()
        ' 
        ' txtmenu
        ' 
        txtmenu.AutoSize = True
        txtmenu.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        txtmenu.Location = New Point(351, 18)
        txtmenu.Name = "txtmenu"
        txtmenu.Size = New Size(64, 25)
        txtmenu.TabIndex = 0
        txtmenu.Text = "Menu"
        ' 
        ' txtopciones
        ' 
        txtopciones.BackgroundImage = CType(resources.GetObject("txtopciones.BackgroundImage"), Image)
        txtopciones.Controls.Add(btncerrarsesion)
        txtopciones.Controls.Add(btncontinuar)
        txtopciones.Controls.Add(ComboBox1)
        txtopciones.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        txtopciones.Location = New Point(77, 56)
        txtopciones.Name = "txtopciones"
        txtopciones.Size = New Size(637, 248)
        txtopciones.TabIndex = 1
        txtopciones.TabStop = False
        txtopciones.Text = "Opciones "
        ' 
        ' btncerrarsesion
        ' 
        btncerrarsesion.Location = New Point(33, 184)
        btncerrarsesion.Name = "btncerrarsesion"
        btncerrarsesion.Size = New Size(123, 33)
        btncerrarsesion.TabIndex = 2
        btncerrarsesion.Text = "cerrar sesion"
        btncerrarsesion.UseVisualStyleBackColor = True
        ' 
        ' btncontinuar
        ' 
        btncontinuar.Location = New Point(500, 184)
        btncontinuar.Name = "btncontinuar"
        btncontinuar.Size = New Size(110, 33)
        btncontinuar.TabIndex = 1
        btncontinuar.Text = "Continuar"
        btncontinuar.UseVisualStyleBackColor = True
        ' 
        ' ComboBox1
        ' 
        ComboBox1.FormattingEnabled = True
        ComboBox1.Items.AddRange(New Object() {"Consultar", "Capturar", "Pedidos", "Modificar"})
        ComboBox1.Location = New Point(254, 57)
        ComboBox1.Name = "ComboBox1"
        ComboBox1.Size = New Size(121, 23)
        ComboBox1.TabIndex = 0
        ' 
        ' Form2
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), Image)
        ClientSize = New Size(800, 450)
        Controls.Add(txtopciones)
        Controls.Add(txtmenu)
        Name = "Form2"
        Text = "Almacen"
        txtopciones.ResumeLayout(False)
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents txtmenu As Label
    Friend WithEvents txtopciones As GroupBox
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents btncerrarsesion As Button
    Friend WithEvents btncontinuar As Button
End Class
