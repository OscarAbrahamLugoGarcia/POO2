﻿Public Class Form3
    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load



        ' Crear columnas
        dgvStock.Columns.Add("codigo", "Código")
        dgvStock.Columns.Add("producto", "Producto")
        dgvStock.Columns.Add("cantidad", "Cantidad")
        dgvStock.Columns.Add("ubicacion", "Ubicación")

        ' Agregar filas de ejemplo
        dgvStock.Rows.Add("LL001", "Llantas 14'' Michelin", 20, "Estante A1")
        dgvStock.Rows.Add("LL002", "Llantas 15'' Pirelli", 15, "Estante A2")
        dgvStock.Rows.Add("LL003", "Llantas 16'' Bridgestone", 8, "Estante B1")

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles mostraringresaid.Click

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txtbuscar.TextChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnbuscar.Click

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnatras.Click
        Me.Close()
    End Sub
End Class