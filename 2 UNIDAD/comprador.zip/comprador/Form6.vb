﻿Public Class Form6
    Private Sub CheckBox4_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox4.CheckedChanged

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Form7.Show()
        If CheckBox1.Checked = True Then
            Form7.ListBox1.Items.Add("
Opcion7
Tipo: Radial
Medida: 215/60 R16 
Indice de carga/velocidad: 95H
Uso: Ciudad/sedan
Marca: firestone firehawk AS
")
        End If
        If CheckBox2.Checked = True Then
            Form7.ListBox1.Items.Add("
Opcion8
Tipo: Todo terreno A/T 
Medida: 275/65 R18
Indice de carga/velocidad: 116T
Uso: Suv/Offroad
Marca: Toyo Open Country A/T III")

        End If
        If CheckBox3.Checked = True Then
            Form7.ListBox1.Items.Add("
Opcion9
Tipo:Touring
Medida: 195/55 R15
Indice de carga/velocidad: 85V
Uso: Compacto
Marca: Pirelli cinturato P1 verde")
        End If
        If CheckBox4.Checked = True Then
            Form7.ListBox1.Items.Add("
Opcion10
Tipo: UHP
Medida: 225/40 R16 
Indice de carga/velocidad: 92Y
Uso: Deportivo
Marca: Hankook ventus V12 evo2
")
        End If
        If CheckBox5.Checked = True Then
            Form7.ListBox1.Items.Add("
Opcion11
Tipo: Run flat
Medida: 245/45 R19
Indice de carga/velocidad: 98W
Uso: Premium/seguridad
Marca: Bridgestone driveguard RFT
")
        End If
        If CheckBox6.Checked = True Then
            Form7.ListBox1.Items.Add("
Opcion12
Tipo: Economica
Medida: 165/65 R14
Indice de carga/velocidad: 79T
Uso: Ahorro de combustible
Marca: Kumho sense KR26
")
        End If
        If TextBox1.Text = "" Then
            MsgBox("Ingrese la cantidad")
        Else
            Form7.ListBox2.Items.Add(TextBox1.Text)



        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)
        Form5.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
End Class