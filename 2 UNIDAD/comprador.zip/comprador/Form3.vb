﻿Public Class Form3
    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form4.Show()
        If CheckBox1.Checked = True Then
            Form4.ListBox1.Items.Add(
"Opcion 1
Tamaño: 16 pulgadas
Material: Aluminio
Diseño: 5 radios en V
Acabado: Negro mate
PCD (patron de birlos): 5x114.3
")
        End If
        If CheckBox2.Checked = True Then
            Form4.ListBox1.Items.Add("
Opcion 2
Tamaño: 17 pulgadas
Material: Acero
Diseño: Tradicional solido
Acabado: Pintado en gris
PCD: 6x139.7")

        End If
        If CheckBox3.Checked = True Then
            Form4.ListBox1.Items.Add("
Opcion 3
Tamaño: 15 pulgadas
Material: Aluminio
Diseño: Estrella de 8 radios
Acabado: Pulido con borde cromado
PCD: 4x100")
        End If
        If CheckBox4.Checked = True Then
            Form4.ListBox1.Items.Add("
Opcion 4
Tamaño: 18 pulgadas
Material: Aleacion ligera
Diseño: Multirradio
Acabado: Gris grafito
PCD: 5x120")

        End If
        If CheckBox5.Checked = True Then
            Form4.ListBox1.Items.Add("
Opcion 5
Tamaño: 20 pulgadas
Material: Forjado
Diseño: 10 redios delgados
Acabado: Cromo espejo
PCD: 5x112
")
        End If
        If CheckBox6.Checked = True Then
            Form4.ListBox1.Items.Add("
Opcion 6 
Tamaño: 14 pulgadas
Material: Acero
Diseño: Estilo retro clasico
Acabado: Negro brillante
PCD: 4x108")
        End If
        If TextBox1.Text = "" Then
            MsgBox("Ingrese la cantidad")
        Else
            Form4.ListBox2.Items.Add(TextBox1.Text)
        End If
    End Sub

    Private Sub NumericUpDown1_ValueChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)
        Form5.Show()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Form8.Show()
    End Sub
End Class