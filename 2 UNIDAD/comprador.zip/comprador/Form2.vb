﻿Public Class Form2
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub PictureBox1_Click_1(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs)

    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form7.Show()
        If CheckBox1.Checked = True Then
            Form7.ListBox1.Items.Add(
"Opcion 1
Tipo: Radial
Medida: 205/55 R16
Indice de carga/velocidad: 91V
Uso: Turismo / Ciudad
Marca: Bridgestone Turanza T005")
        End If

        If CheckBox2.Checked = True Then
            Form7.ListBox1.Items.Add("
Opcion 2
Tipo: Todo Terreno (AT)
Medida: 265/70 R17
Indice de carga/velocidad: 115T
Uso: SUV / Pickup
Marca: BFGoodrich All-Terrain T/A KO2")
        End If
        If CheckBox3.Checked = True Then
            Form7.ListBox1.Items.Add("
Opcion 3
Tipo: Alta velocidad (UHP)
Medida: 225/45 ZR18
Indice de carga/velocidad: 95Y
Uso: Deportivo / Carretera
Marca_ Michelin Pilot Sport 4
")
        End If
        If CheckBox4.Checked = True Then
            Form7.ListBox1.Items.Add("
Opcion 4
Tipo: Invierno
Medida: 195/65 R15
Indice de carga/velocidad: 91H
Uso: Auto compacto / Nieve
Marca: Pirelli Winter Sottozero 3
")
        End If
        If CheckBox5.Checked = True Then
            Form7.ListBox1.Items.Add("
Opcion 5
Tipo: Run Flat
Medida: 245/40 R19
Indice de carga/velocidad: 98W
Uso: Sedan Premiun
Marca: Continental ContiSportContact SSR")
        End If
        If CheckBox6.Checked = True Then
            Form7.ListBox1.Items.Add("
Opcion 6
Tipo: Ecologica
Medida: 185/65 R14
Indice de carga/velocidad: 86T
Uso: Ciudad / Ahorro de combustible
Marca: Goodyear Assurance Fuel Max")
        End If
        If TextBox1.Text = "" Then
            MsgBox("Ingrese la cantidad")
        Else
            Form7.ListBox2.Items.Add(TextBox1.Text)



        End If
    End Sub

    Private Sub CheckBox7_CheckedChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Form6.Show()
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub
End Class