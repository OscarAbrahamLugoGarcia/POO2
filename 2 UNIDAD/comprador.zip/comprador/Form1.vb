﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Select Case ComboBox1.SelectedItem
            Case "Llantas"
                Form2.Show()
            Case "Rines"
                Form3.Show()
            Case Else
                MessageBox.Show("Por favor, selecciona una opción válida del ComboBox.")
        End Select
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)
        Form2.Show()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs)
        Form3.Show()
    End Sub

    Private Sub HScrollBar1_Scroll(sender As Object, e As ScrollEventArgs)

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged

    End Sub
End Class