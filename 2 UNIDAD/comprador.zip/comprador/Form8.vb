﻿Public Class Form8
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Form4.Show()
        If CheckBox1.Checked = True Then
            Form4.ListBox1.Items.Add(
"Opcion 7
Tamaño: 16 pulgadas
Material: Aluminio
Diseño: 5 radios dobles
Acabado: Negro mate
PCD: 5x114.3
")
        End If
        If CheckBox2.Checked = True Then
            Form4.ListBox1.Items.Add("
Opcion 8 
Tamaño: 18 pulgadas
Material: Aleacion
Diseño: Multirradio
Acabado: Gris satinado
PCD: 5x120")

        End If
        If CheckBox3.Checked = True Then
            Form4.ListBox1.Items.Add("
Opcion 9
Tamaño: 17 pulgadas
Material: Acero
Diseño: clasico circular
Acabado: Negro 
PCD: 6x139.7")
        End If
        If CheckBox4.Checked = True Then
            Form4.ListBox1.Items.Add("
Opcion 10 
Tamaño: 20 pulgadas
Material: Forjado
Diseño: 6 radios divididos
Acabado: Cromo brillante
PCD: 5x112")

        End If
        If CheckBox5.Checked = True Then
            Form4.ListBox1.Items.Add("
Opcion 11
Tamaño: 15 pulgadas
Material: Aluminio
Diseño: Estrella de 5 puntas
Acabado: Pulido
PCD: 4x100
")
        End If
        If CheckBox6.Checked = True Then
            Form4.ListBox1.Items.Add("
Opcion 12
Tamaño: 19 pulgadas
Material: Aleacion
Diseño: 10 radios curvos
Acabado: Negro con rojo
PCD: 5x114.3")
        End If
        If TextBox1.Text = "" Then
            MsgBox("Ingrese la cantidad")
        Else
            Form4.ListBox2.Items.Add(TextBox1.Text)
        End If
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub
End Class